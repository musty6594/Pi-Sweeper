# Pi Sweeper Bot (Test Mode)

This bot watches a Pi wallet address and, when the unlock epoch is reached, it simulates claiming the balance and sweeping it to a safe wallet.

## Configuration
- COMPROMISED_PUBLIC: Your compromised Pi wallet public key.
- SAFE_WALLET: The wallet to receive the Pi after unlocking.
- UNLOCK_EPOCH: UNIX timestamp of the unlock date/time.
- BALANCE_ID: Will be replaced just before unlock.

## Deployment
1. Install Wrangler:
   ```bash
   npm install -g wrangler
   ```
2. Login to Cloudflare:
   ```bash
   wrangler login
   ```
3. Publish the bot:
   ```bash
   wrangler publish
   ```

## Secrets (for mainnet deployment)
```bash
wrangler secret put SEED --env production
```